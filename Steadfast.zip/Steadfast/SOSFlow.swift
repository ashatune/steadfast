import SwiftUI

// MARK: - Feelings & Stages
enum Feeling: String, CaseIterable, Identifiable {
    case stressedWorried = "Stressed / Worried"
    case panic = "Panic"
    case nervous = "Nervous"
    case selfHarm = "Self-harm urges"
    var id: String { rawValue }
}

private enum SOSStage { case select, acknowledge, step1, prompt, step2, safety, checkin, finale, done }

// MARK: - Flow
struct SOSFlow: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    @State private var stage: SOSStage = .select
    @State private var feeling: Feeling? = nil

    private let ackSeconds = 3

    // Stressed/Worried countdown (body scan + breathing)
    @State private var worriedRemaining: Int = 0
    @State private var worriedTimer: Timer? = nil

    private func startWorriedTimer(total: Int) {
        worriedTimer?.invalidate()
        worriedRemaining = total
        worriedTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { t in
            if worriedRemaining > 0 { worriedRemaining -= 1 } else { t.invalidate(); worriedTimer = nil }
        }
    }
    private func stopWorriedTimer() { worriedTimer?.invalidate(); worriedTimer = nil }
    private func timeString(_ t: Int) -> String {
        let m = max(t,0) / 60, s = max(t,0) % 60
        return String(format: "%01d:%02d", m, s)
    }

    // Per-feeling finale messages
    private func finaleMessages(for feeling: Feeling?) -> [String] {
        switch feeling {
        case .stressedWorried:
            return ["You showed up for yourself today.",
                    "God has you — and this situation — in His hands.",
                    "Take the next small step with a steady heart."]
        case .panic:
            return ["You rode the wave. Well done.",
                    "God is with you in every breath.",
                    "You are safe right now."]
        case .nervous:
            return ["You practiced courage.",
                    "God goes before you and stands beside you.",
                    "You’re not alone."]
        case .selfHarm:
            return ["You chose safety. That matters.",
                    "God’s care covers you, fully and kindly.",
                    "Keep reaching for support."]
        case .none:
            return ["God is with you.", "You are safe.", "Be gentle with yourself."]
        }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                // Background
                CalmCloudsBackground(
                    base: Theme.bg,
                    cloudColors: [
                        Color.blue.opacity(0.34),
                        Color.mint.opacity(0.42),
                        Color.pink.opacity(0.80)
                    ],
                    count: 10, speed: 0.08
                )

                // Content
                Group {
                    switch stage {
                    case .select:
                        FeelingPick(feeling: $feeling) { stage = .acknowledge }

                    case .acknowledge:
                        AcknowledgementView(feeling: feeling, seconds: ackSeconds)
                            .onComplete { routeFromAcknowledge() }

                    case .step1:
                        switch feeling {
                        case .panic:
                            // 5–4–3–2–1
                            Grounding54321View(
                                totalDuration: 55,
                                perStepDurations: [12,11,11,11,10],
                                verses: versesForPanicGrounding,
                                showTitle: false
                            )
                            .onComplete { stage = .prompt }

                        case .stressedWorried:
                            // ~90s body scan
                            BodyScanView(lines: bodyScanScript, perStepSeconds: 9, fade: 0.6)
                                .onComplete { stage = .prompt }

                        case .nervous:
                            // 90s scripture breathing
                            StageTimer(seconds: 90) { stage = .finale } content: {
                                AnchorBreathView(
                                    verse: Verse(ref: "Isaiah 41:10",
                                                 breathIn: "Fear not, for I am with you",
                                                 breathOut: "I will uphold you",
                                                 text: nil),
                                    totalDuration: 90,
                                    inhaleSecs: 4,
                                    exhaleSecs: 6
                                )
                            }

                        case .selfHarm:
                            // 5–4–3–2–1
                            Grounding54321View(
                                totalDuration: 55,
                                perStepDurations: [12,11,11,11,10],
                                verses: [
                                    "Psalm 91:1 — Under His wings you find refuge.",
                                    "Psalm 34:18 — The Lord is near to the brokenhearted.",
                                    "Isaiah 41:10 — I am with you.",
                                    "1 Pet 5:7 — Cast your care on Him."
                                ],
                                showTitle: false
                            )
                            .onComplete { stage = .prompt }

                        case .none:
                            EmptyView()
                        }

                    case .prompt:
                        // single calm prompt before breathing for all paths that use it
                        VersePromptView(
                            text: "Let’s breathe.",
                            seconds: 2
                        )
                        .onComplete { stage = .step2 }

                    case .step2:
                        switch feeling {
                        case .panic:
                            BreathingView(
                                pattern: .box,
                                totalDuration: 55,
                                verses: versesForBox,
                                showTitle: false
                            )
                            .onComplete { stage = .finale }

                        case .stressedWorried:
                            // 1-minute scripture breathing after body scan
                            StageTimer(seconds: 60) { stage = .finale } content: {
                                AnchorBreathView(
                                    verse: Verse(
                                        ref: "1 Peter 5:7",
                                        breathIn:  "Cast all your care",
                                        breathOut: "for He cares for you",
                                        text: nil
                                    ),
                                    totalDuration: 60,
                                    inhaleSecs: 4,
                                    exhaleSecs: 6
                                )
                            }

                        case .selfHarm:
                            // 1-minute scripture breathing, then check-in
                            StageTimer(seconds: 60) {
                                print("⏰ self-harm breathing finished → checkin")
                                stage = .checkin
                            } content: {
                                AnchorBreathView(
                                    verse: Verse(
                                        ref: "Psalm 23:1",
                                        breathIn:  "The Lord is my shepherd",
                                        breathOut: "I lack nothing",
                                        text: nil
                                    ),
                                    totalDuration: 60,
                                    inhaleSecs: 4,
                                    exhaleSecs: 6
                                )
                            }

                        default:
                            EmptyView()
                        }

                    case .safety:
                        SafetySupportView(
                            onContinue: { stage = .step1 }, // continue into calming sequence
                            onClose: { dismiss() }
                        )

                    case .checkin:
                        SelfHarmCheckInView(
                            onRepeat:  { print("🔁 repeat");  stage = .step1 },
                            onSupport: { print("🆘 support"); stage = .safety },
                            onFinish:  { print("✅ finish");  stage = .finale }   // must set .finale
                        )

                    case .finale:
                        if feeling == .selfHarm {
                            SelfHarmFinalView(onDone: { stage = .done })
                                .onAppear { print("🎯 SelfHarmFinalView appeared") }
                        } else {
                            FinalCalmView(totalDuration: 12, messages: finaleMessages(for: feeling))
                                .onComplete { stage = .done }
                        }

                    case .done:
                        SOSDone(restart: { stage = .select; feeling = nil })
                    }
                }
                .id(stage) // force rebuild on stage switch
                .transition(.opacity)
                .animation(.easeInOut(duration: 0.3), value: stage)
                .padding()

                // Timer overlay for Stressed/Worried (step1 + step2)
                if feeling == .stressedWorried && (stage == .step1 || stage == .step2) {
                    VStack {
                        Spacer()
                        Text(timeString(worriedRemaining))
                            .font(.callout)
                            .monospacedDigit()
                            .foregroundStyle(Theme.inkSecondary)
                            .padding(.vertical, 8)
                    }
                    .padding(.bottom, 28)
                    .transition(.opacity)
                }
            }
            .navigationTitle("Breathe and Reset")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Close") { dismiss() } }
            }
            .toolbarBackground(.clear, for: .navigationBar)
            .toolbarBackgroundVisibility(.visible, for: .navigationBar)
        }
        .tint(Theme.accent)
        .foregroundStyle(Theme.ink)
        // Audio + timer hooks + DEBUG
        .onChange(of: stage) { newStage in
            print("🔷 SOS stage ->", newStage, "| feeling:", String(describing: feeling))
            switch newStage {
            case .acknowledge:
                SoundManager.shared.playAmbient(named: "meditate1", startVolume: 0.0, loop: true)
                SoundManager.shared.fade(to: 0.6, duration: 1.2)
            case .finale, .done:
                if feeling == .stressedWorried { stopWorriedTimer() }
                SoundManager.shared.fade(to: 0.0, duration: 1.0, stopAfter: true)
            default:
                break
            }
        }
        .onDisappear {
            if feeling == .stressedWorried { stopWorriedTimer() }
            SoundManager.shared.fade(to: 0.0, duration: 0.6, stopAfter: true)
        }
    }

    private func routeFromAcknowledge() {
        guard let f = feeling else { return }
        switch f {
        case .panic, .stressedWorried, .nervous:
            stage = .step1
            if f == .stressedWorried {
                // ~90s scan + 60s breathing = 150s
                startWorriedTimer(total: 150)
            }
        case .selfHarm:
            stage = .safety
        }
    }

    // Verses / scripts
    private var versesForPanicGrounding: [String] {
        [
            "Isaiah 41:10 — I am with you.",
            "Psalm 46:1 — God is our refuge.",
            "2 Tim 1:7 — Power, love, self-control.",
            "Isaiah 43:2 — I will be with you."
        ]
    }
    private var bodyScanScript: [String] {
        [
            "Settle into a comfortable position—either lying down or sitting upright.",
            "Dim your eyes and take a slow breath in… and out.",
            "God is with you.",
            "Bring your attention to your feet. Notice any sensations—tingling, warmth, or pressure.",
            "Move your awareness up through your legs, allowing them to feel heavy and supported.",
            "Shift to your hips and lower back. Notice the contact with the surface beneath you. Let yourself sink into that support.",
            "Bring attention to your abdomen and chest. Feel the gentle rise and fall of your breath.",
            "Notice your hands and arms, any tingling or heaviness. Allow them to soften.",
            "Move up to your shoulders and neck, releasing any tension with your exhale.",
            "Finally, bring awareness to your face—softening your jaw, eyes, and forehead.",
            "Now sense your whole body as one—resting, supported, breathing.",
            "Take one more deep breath in… and slowly out. Wiggle your fingers and toes, stretch gently, and when you’re ready, open your eyes."
        ]
    }
    private var versesForBox: [String] {
        [
            "Psalm 34:4 — I sought the Lord; He answered me.",
            "Isaiah 26:3 — Perfect peace for a steadfast mind.",
            "Phil 4:7 — Peace of God will guard you.",
            "Psalm 56:3 — When I am afraid, I trust You."
        ]
    }
}

// MARK: - Picker
struct FeelingPick: View {
    @Binding var feeling: Feeling?
    var onNext: () -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("What are you feeling?").font(.title2).bold()
            ForEach(Feeling.allCases) { f in
                SelectRow(isSelected: feeling == f, title: f.rawValue) {
                    feeling = f; onNext()
                }
            }
            Text("You’re safe right now. Let’s pick one small practice.")
                .font(.footnote)
                .foregroundStyle(Theme.inkSecondary)
        }
    }
}

// MARK: - Rows & Acknowledge
struct SelectRow: View {
    let isSelected: Bool
    let title: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack {
                Text(title)
                Spacer()
                if isSelected { Image(systemName: "checkmark.circle.fill").foregroundStyle(Theme.accent) }
            }
            .padding()
            .background(RoundedRectangle(cornerRadius: 14).fill(Theme.surface))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(isSelected ? Theme.accent : Theme.line, lineWidth: isSelected ? 1.5 : 1))
        }
        .buttonStyle(.plain)
    }
}

struct AcknowledgementView: View {
    let feeling: Feeling?
    let seconds: Int
    @Environment(\.onComplete) private var onComplete
    @State private var countdown = 0
    @State private var timer: Timer?
    var body: some View {
        if feeling == .selfHarm {
            SelfHarmAckSequenceView(
                lines: [
                    "Thank you for coming here.",
                    "You are distressed, and that’s OK to acknowledge.",
                    "What you’re feeling is real.",
                    "You are allowed to pause.",
                    "Please don’t hurt yourself.",
                    "Your life is precious.",
                    "This wave will pass.",
                    "You are not alone.",
                    "God is with you right now.",
                    "He is near to the brokenhearted. (Psalm 34:18)",
                    "He wants to hear from you.",
                    "He cares for you."
                ],
                perStepSeconds: 2.2, fade: 0.6
            )
        } else {
            VStack(spacing: 16) {
                Text(ackText).multilineTextAlignment(.center)
                Text("Starting in \(countdown)…")
                    .font(.footnote).monospacedDigit()
                    .foregroundStyle(Theme.inkSecondary)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .onAppear { start() }
            .onDisappear { stop() }
        }
    }
    private var ackText: String {
        let label = feeling?.rawValue.lowercased() ?? "this"
        return "You are feeling \(label), and that’s OK.\nGod is here with you."
    }
    private func start() {
        countdown = seconds
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { t in
            countdown -= 1
            if countdown <= 0 { t.invalidate(); stop(); onComplete?() }
        }
    }
    private func stop() { timer?.invalidate(); timer = nil }
}

// Self-harm acknowledgement sequence
private struct SelfHarmAckSequenceView: View {
    let lines: [String]
    var perStepSeconds: TimeInterval = 2.2
    var fade: TimeInterval = 0.6
    @Environment(\.onComplete) private var onComplete
    @State private var index = 0
    @State private var visible = false
    @State private var started = false
    @State private var cancelled = false
    var body: some View {
        VStack(spacing: 14) {
            if let line = currentLine {
                Text(line)
                    .multilineTextAlignment(.center)
                    .font(.title3)
                    .padding(.horizontal, 20)
                    .opacity(visible ? 1 : 0)
                    .animation(.easeInOut(duration: fade), value: visible)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .onAppear { guard !started else { return }; started = true; cancelled = false; playStep() }
        .onDisappear {
            TTSManager.shared.stop()
            cancelled = true }
    }
    private var currentLine: String? {
        guard lines.indices.contains(index) else { return nil }
        return lines[index]
    }
    private func playStep() {
        guard !cancelled else { return }
        guard lines.indices.contains(index) else { onComplete?(); return }
        withAnimation(.easeInOut(duration: fade)) { visible = true }
        TTSManager.shared.speak(lines[index])   // ← add this
        DispatchQueue.main.asyncAfter(deadline: .now() + perStepSeconds) {
            guard !cancelled else { return }
            withAnimation(.easeInOut(duration: fade)) { visible = false }
            TTSManager.shared.speak(lines[index])   // ← add this
            DispatchQueue.main.asyncAfter(deadline: .now() + fade) {
                guard !cancelled else { return }
                if lines.indices.contains(index + 1) { index += 1; playStep() }
                else { onComplete?() }
            }
        }
    }
}

// Interstitial prompt
struct VersePromptView: View {
    let text: String
    let seconds: Int
    @Environment(\.onComplete) private var onComplete
    @State private var visible = false
    var body: some View {
        VStack {
            Text(text)
                .multilineTextAlignment(.center)
                .font(.title3)
                .opacity(visible ? 1 : 0)
                .animation(.easeInOut(duration: 0.6), value: visible)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .onAppear {
            visible = true
            TTSManager.shared.speak(text) // speak the prompt
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(seconds)) {
                withAnimation(.easeInOut(duration: 0.5)) { visible = false }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.55) { onComplete?() }
            }
        }
    }
}

// Safety screen
struct SafetySupportView: View {
    @Environment(\.openURL) private var openURL
    var onContinue: () -> Void
    var onClose: () -> Void
    var body: some View {
        VStack(spacing: 14) {
            Text("You’re not alone.").font(.title3).bold()
            Text("If you feel at risk of harming yourself, please seek immediate help.")
                .multilineTextAlignment(.center)
                .foregroundStyle(Theme.inkSecondary)
                .padding(.horizontal)
            VStack(spacing: 10) {
                Button { if let url = URL(string: "tel://988") { openURL(url) } }
                    label: { Label("Call 988 (US)", systemImage: "phone.fill") }
                    .buttonStyle(.borderedProminent)
                Button { if let url = URL(string: "sms://741741") { openURL(url) } }
                    label: { Label("Text 741741 (US)", systemImage: "message.fill") }
                    .buttonStyle(.bordered)
                Text("If you’re outside the US, contact your local emergency number or visit the nearest ER.")
                    .font(.footnote).foregroundStyle(Theme.inkSecondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }
            .padding(.top, 4)
            Divider().padding(.vertical, 8)
            Button("I’m safe — continue to a calm exercise") { onContinue() }.buttonStyle(.bordered)
            Button("Close") { onClose() }.foregroundStyle(Theme.inkSecondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }
}

// Tiny timed wrapper (for AnchorBreathView)
struct StageTimer<Content: View>: View {
    let seconds: Int
    let onDone: () -> Void
    @ViewBuilder var content: () -> Content
    @State private var fired = false
    var body: some View {
        content()
            .onAppear {
                guard !fired else { return }
                fired = true
                DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(seconds)) { onDone() }
            }
    }
}

// Self-harm check-in
struct SelfHarmCheckInView: View {
    var onRepeat: () -> Void
    var onSupport: () -> Void
    var onFinish: () -> Void
    var body: some View {
        VStack(spacing: 16) {
            Text("How are you feeling now?").font(.title3).bold()
            Text("If you want, we can repeat the grounding and breathing.")
                .multilineTextAlignment(.center)
                .foregroundStyle(Theme.inkSecondary)
                .padding(.horizontal)
            HStack(spacing: 12) {
                Button("Repeat") { print("🔁 repeat"); onRepeat() }.buttonStyle(.bordered)
                Button("Get support") { print("🆘 support"); onSupport() }.buttonStyle(.bordered).foregroundStyle(Theme.inkSecondary)
                Button("Finish") { print("✅ finish"); onFinish() }.buttonStyle(.borderedProminent)
            }
            .padding(.top, 6)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }
}

// Done
struct SOSDone: View {
    @Environment(\.dismiss) private var dismiss
    var restart: (() -> Void)? = nil
    var extraLine: String? = nil
    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "checkmark.seal.fill").font(.largeTitle).foregroundStyle(Theme.accent)
            Text("Nice—one small step taken.").font(.title3).bold()
            if let extraLine {
                Text(extraLine).multilineTextAlignment(.center).foregroundStyle(Theme.inkSecondary)
            } else {
                Text("Consider a sip of water or sit by a window for a minute.").foregroundStyle(Theme.inkSecondary)
            }
            HStack(spacing: 12) {
                if let restart {
                    Button { restart() } label: { Label("Restart", systemImage: "arrow.clockwise") }
                        .buttonStyle(.bordered)
                }
                Button("Done") { dismiss() }.buttonStyle(.borderedProminent)
            }
            .padding(.top, 6)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }
}

struct SelfHarmFinalView: View {
    @Environment(\.openURL) private var openURL
    var onDone: () -> Void
    var body: some View {
        VStack(spacing: 16) {
            Text("Thank you for doing this practice.")
                .font(.title3).bold()
                .multilineTextAlignment(.center)
            Text("You’re invited to sit here with God as long as you need.")
                .multilineTextAlignment(.center)
                .foregroundStyle(Theme.inkSecondary)
            Text("When you’re ready, consider calling a trusted friend or someone you feel safe with.")
                .multilineTextAlignment(.center)
                .foregroundStyle(Theme.inkSecondary)
                .padding(.horizontal)
            Spacer(minLength: 8)
            HStack(spacing: 12) {
                Button {
                    if let url = URL(string: "tel://988") { openURL(url) }
                } label: { Label("Call 988 (US)", systemImage: "phone.fill") }
                .buttonStyle(.borderedProminent)
                Button("Done") { onDone() }
                    .buttonStyle(.bordered)
            }
            .padding(.top, 6)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
        .onAppear { print("🎯 SelfHarmFinalView appeared") }
    }
}
