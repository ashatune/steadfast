import SwiftUI

struct SOSButton: View {
    var action: () -> Void
    var imageName: String = "SOSIcon"   // your asset name
    var imageIsTemplate: Bool = false   // true = tinted template (PDF), false = full-color PNG/JPG
    var size: CGFloat = 160             // overall button diameter
    var iconScale: CGFloat = 0.55       // fraction of circle used by the image (0.55 = 55%)
    var accessibilityLabelText: String = "Open Reset Calm"

    @State private var animate = false

    var body: some View {
        Button(action: action) {
            ZStack {
                // Pulsing circle
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [Theme.accent2.opacity(0.7), Theme.accent.opacity(0.7)],
                            startPoint: .topLeading, endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: size, height: size)
                    .overlay(Circle().stroke(Theme.line, lineWidth: 1))
                    .scaleEffect(animate ? 1.05 : 0.95)
                    .animation(.easeInOut(duration: 1.6).repeatForever(autoreverses: true), value: animate)

                // Centered image (no text)
                Group {
                    if imageIsTemplate {
                        Image(imageName)
                            .renderingMode(.template)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .foregroundStyle(Theme.accent)
                    } else {
                        Image(imageName)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                    }
                }
                .frame(width: size * iconScale, height: size * iconScale)
            }
        }
        .buttonStyle(.plain)
        .contentShape(Circle())                 // bigger, circular tap target
        .onAppear { animate = true }
        .accessibilityLabel(accessibilityLabelText)
    }
}
