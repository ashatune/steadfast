import SwiftUI

struct VerseCard: View {
    let verse: Verse
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: "book")
            VStack(alignment: .leading, spacing: 4) {
                Text(verse.ref).font(.headline)
                if let bi = verse.breathIn, let bo = verse.breathOut {
                    Text("Inhale: \(bi)\nExhale: \(bo)")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }
            Spacer()
        }
        .padding()
        // VerseCard.swift
        .background(RoundedRectangle(cornerRadius: 16).fill(Theme.surface))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Theme.line))

    }
}
