import UIKit

enum Haptics {
    static func bump() {
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }
    // Optional extras:
    static func tap() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }
}
