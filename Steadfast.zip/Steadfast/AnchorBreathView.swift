import SwiftUI

struct AnchorBreathView: View {
    let verse: Verse
    var totalDuration: Int = 60
    var inhaleSecs: Int = 4
    var exhaleSecs: Int = 6

    @Environment(\.dismiss) private var dismiss
    @State private var phase: Phase = .inhale
    @State private var countdown: Int = 60
    @State private var phaseRemaining: Int = 0
    @State private var scale: CGFloat = 0.95

    @State private var phaseTimer: Timer?
    @State private var countdownTimer: Timer?

    enum Phase { case inhale, exhale }

    var body: some View {
        VStack(spacing: 20) {
            Text(verse.ref).font(.headline)

            ZStack {
                Circle()
                    .stroke(
                            AngularGradient(colors: [Theme.accent2, Theme.accent, Theme.accent2],
                                            center: .center),
                            lineWidth: 8
                        )
                    .frame(width: 220, height: 220)
                    .scaleEffect(scale) // animation handled with explicit durations per phase

                VStack(spacing: 8) {
                    Text(phase == .inhale ? inhaleText : exhaleText)
                        .multilineTextAlignment(.center)
                        .font(.title3)
                        .padding(.horizontal)
                    Text((phase == .inhale ? "Inhale" : "Exhale") + " • \(phaseRemaining)s")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }

            Text(timeString(countdown))
                .font(.footnote)
                .monospacedDigit()
                .foregroundStyle(.secondary)

            // Optional: quick link to open full passage in Bible
            if let parsed = BibleStore.shared.parseReference(verse.ref) {
                NavigationLink("Open in Bible") {
                    PassageView(book: parsed.book,
                                chapter: parsed.chapter,
                                verseStart: parsed.verseStart,
                                verseEnd: parsed.verseEnd)
                }
                .buttonStyle(.bordered)
            }
        }
        .padding()
        .navigationTitle("Breathe with Scripture")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .topBarLeading) { Button("Close") { dismiss() } } }
        .onAppear { start() }
        .onDisappear { stop() }
    }

    // MARK: - Text logic
    private var inhaleText: String {
        if let bi = verse.breathIn, !bi.isEmpty { return bi }
        return splitVerse().0
    }
    private var exhaleText: String {
        if let bo = verse.breathOut, !bo.isEmpty { return bo }
        return splitVerse().1
    }

    /// If no breathIn/Out provided, split verse text roughly in half by words.
    private func splitVerse() -> (String, String) {
        guard let t = verse.text, !t.isEmpty else { return (verse.ref, "Be still.") }
        let words = t.split(separator: " ")
        let mid = max(1, words.count / 2)
        let first = words[..<mid].joined(separator: " ")
        let second = words[mid...].joined(separator: " ")
        return (first, second.isEmpty ? first : second)
    }

    // MARK: - Timers / Animation
    private func start() {
        stop()
        countdown = totalDuration
        phase = .inhale
        phaseRemaining = inhaleSecs
        animateScale(to: 1.15, duration: Double(inhaleSecs)) // expand over inhale
        Haptics.bump()

        // overall countdown
        countdownTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { t in
            countdown -= 1
            if countdown <= 0 {
                t.invalidate()
                stop()
                dismiss()
            }
        }

        // phase driver
        phaseTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { t in
            phaseRemaining -= 1
            if phaseRemaining <= 0 {
                switch phase {
                case .inhale:
                    phase = .exhale
                    phaseRemaining = exhaleSecs
                    animateScale(to: 0.85, duration: Double(exhaleSecs)) // contract over exhale
                case .exhale:
                    phase = .inhale
                    phaseRemaining = inhaleSecs
                    animateScale(to: 1.15, duration: Double(inhaleSecs))
                }
                Haptics.bump()
            }
        }
    }

    private func stop() {
        phaseTimer?.invalidate(); phaseTimer = nil
        countdownTimer?.invalidate(); countdownTimer = nil
    }

    private func animateScale(to target: CGFloat, duration: Double) {
        withAnimation(.easeInOut(duration: duration)) {
            scale = target
        }
    }

    private func timeString(_ t: Int) -> String {
        let m = max(t,0) / 60, s = max(t,0) % 60
        return String(format: "%01d:%02d", m, s)
    }
}
