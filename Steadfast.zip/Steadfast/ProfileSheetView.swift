// ProfileSheetView.swift
import SwiftUI

struct ProfileSheetView: View {
    @EnvironmentObject var vm: AppViewModel
    @Environment(\.dismiss) private var dismiss

    @State private var firstName: String = ""
    @State private var birthdate: Date = Calendar.current.date(byAdding: .year, value: -25, to: Date()) ?? Date()
    @State private var hasBirthdate = false   // toggle so birthdate is optional

    private var saveDisabled: Bool { firstName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }

    var body: some View {
        Form {
            Section("Your Info") {
                TextField("First name", text: $firstName)
                    .textInputAutocapitalization(.words)
                    .submitLabel(.done)

                Toggle("Add birthdate", isOn: $hasBirthdate)

                if hasBirthdate {
                    DatePicker("Birthdate",
                               selection: $birthdate,
                               in: dateRange,
                               displayedComponents: .date)
                }
            }

            Section {
                Button("Save") { save() }
                    .buttonStyle(.borderedProminent)
                    .disabled(saveDisabled)

                Button("Cancel", role: .cancel) { dismiss() }
            }
        }
        .navigationTitle("Profile")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            firstName = vm.profileFirstName
            if let d = vm.profileBirthdate {
                birthdate = d
                hasBirthdate = true
            } else {
                hasBirthdate = false
            }
        }
    }

    private var dateRange: ClosedRange<Date> {
        let cal = Calendar.current
        let min = cal.date(from: DateComponents(year: 1900, month: 1, day: 1)) ?? Date(timeIntervalSince1970: 0)
        let max = Date()
        return min...max
    }

    private func save() {
        vm.profileFirstName = firstName.trimmingCharacters(in: .whitespacesAndNewlines)
        vm.profileBirthdate = hasBirthdate ? birthdate : nil
        dismiss()
    }
}
