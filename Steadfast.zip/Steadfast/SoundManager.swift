import Foundation
import AVFoundation
import UIKit

final class SoundManager: NSObject {
    static let shared = SoundManager()
    private override init() { super.init() }

    private var player: AVAudioPlayer?
    private var fadeTimer: Timer?

    // Call once (e.g., app launch). Use .ambient so silent switch mutes audio.
    func configureAudioSession(ignoresSilentSwitch: Bool = false) {
        let session = AVAudioSession.sharedInstance()
        do {
            if ignoresSilentSwitch {
                try session.setCategory(.playback, options: [.mixWithOthers]) // plays even if phone is on silent
            } else {
                try session.setCategory(.ambient,  options: [.mixWithOthers]) // respects silent switch
            }
            try session.setActive(true)
        } catch { print("AudioSession error:", error) }
    }

    /// Play a looped ambient file at a starting volume (0.0–1.0)
    func playAmbient(named name: String, ext: String = "m4a", startVolume: Float = 0.0, loop: Bool = true) {
        stop() // stop any existing sound
        guard let url = Bundle.main.url(forResource: name, withExtension: ext) else {
            print("⚠️ Missing audio asset:", name, ext); return
        }
        do {
            let p = try AVAudioPlayer(contentsOf: url)
            p.numberOfLoops = loop ? -1 : 0
            p.volume = startVolume
            p.prepareToPlay()
            p.play()
            player = p
        } catch { print("Audio play error:", error) }
    }

    /// Smoothly fade volume to `target` over `duration`. Optionally stop after.
    func fade(to target: Float, duration: TimeInterval = 1.2, stopAfter: Bool = false) {
        guard let player = player else { return }
        fadeTimer?.invalidate()

        let steps = max(10, Int(duration * 30))   // ~30 fps
        let interval = duration / Double(steps)
        let start = max(0, min(1, player.volume))
        let end   = max(0, min(1, target))
        let delta = end - start
        var i = 0

        fadeTimer = Timer.scheduledTimer(withTimeInterval: interval, repeats: true) { [weak self] t in
            i += 1
            let progress = min(1.0, Float(i) / Float(steps))
            self?.player?.volume = start + delta * progress
            if i >= steps {
                t.invalidate()
                if stopAfter { self?.stop() }
            }
        }
    }

    func stop() {
        fadeTimer?.invalidate(); fadeTimer = nil
        player?.stop(); player = nil
    }
}
