import SwiftUI

@main
struct SteadfastApp: App {
    @StateObject private var appVM = AppViewModel()
    @AppStorage("hasShownSplash") private var hasShownSplash = false
    @State private var showSplash: Bool

    init() {
        _showSplash = State(initialValue: !UserDefaults.standard.bool(forKey: "hasShownSplash"))
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(appVM)
                .overlay { if showSplash { SplashView().transition(.opacity) } }
                .task {
                    if showSplash {
                        try? await Task.sleep(nanoseconds: 1_200_000_000)
                        withAnimation { showSplash = false }
                        hasShownSplash = true
                    }
                }
                // ✅ Configure audio session once when the app UI appears

            .onAppear {
                SoundManager.shared.configureAudioSession(ignoresSilentSwitch: false) // true = play even with mute switch on
                TTSManager.shared.preparePreferredVoice(languages: ["en-US","en-GB"])
            }

        }
    }
}
