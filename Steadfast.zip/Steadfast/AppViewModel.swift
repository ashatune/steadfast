import Foundation
import Combine
import SwiftUI

final class AppViewModel: ObservableObject {

    // MARK: Personalization / UI
    enum FocusArea: String, CaseIterable, Identifiable { case health, worry, panic, sleep, grief, general
        var id: String { rawValue }
    }
    enum GroundingStyle: String, CaseIterable, Identifiable { case breath, scripture, journal, bodyScan
        var id: String { rawValue }
    }

    // MARK: Stored properties (defaults first)
    @Published var focusAreas: Set<FocusArea>             = [.health, .worry]
    @Published var preferredTranslation: BibleTranslation = .esv
    @Published var groundingStyle: GroundingStyle         = .breath

    @Published var library: ScriptureLibrary              = .sample
    @Published var selectedPack: VersePack?               = nil

    @Published var showSOS: Bool                          = false
    @Published var todayVerses: [Verse]                   = []
    
    @Published var isPremium: Bool = false
    @Published var showPaywall: Bool = false


    // Profile
    @Published var profileFirstName: String               = ""
    @Published var profileBirthdate: Date?                = nil
    var profileInitial: String {
        let trimmed = profileFirstName.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.first.map { String($0).uppercased() } ?? "U"
    }

    // Notifications
    @Published var notifEnabled: Bool                     = true
    @Published var morningEnabled: Bool                   = true
    @Published var middayEnabled: Bool                    = true
    @Published var eveningEnabled: Bool                   = true

    @Published var morningTime: Date                      = AppViewModel.makeTime(8, 0)
    @Published var middayTime: Date                       = AppViewModel.makeTime(13, 0)
    @Published var eveningTime: Date                      = AppViewModel.makeTime(21, 0)

    // Voice guidance (TTS) — SINGLE declaration
    @Published var voiceGuidanceEnabled: Bool             = true {
        didSet {
            UserDefaults.standard.set(voiceGuidanceEnabled, forKey: "voice_guidance")
            TTSManager.shared.enabled = voiceGuidanceEnabled
        }
    }

    // MARK: Init
    init() {
        let ud = UserDefaults.standard

        // Profile
        if let name = ud.string(forKey: "profileFirstName") {
            profileFirstName = name
        }
        if let ts = ud.object(forKey: "profileBirthdate") as? TimeInterval {
            profileBirthdate = Date(timeIntervalSince1970: ts)
        }

        // Notifications
        notifEnabled   = (ud.object(forKey: "notif_enabled") as? Bool) ?? notifEnabled
        morningEnabled = (ud.object(forKey: "notif_morning_enabled") as? Bool) ?? morningEnabled
        middayEnabled  = (ud.object(forKey: "notif_midday_enabled") as? Bool) ?? middayEnabled
        eveningEnabled = (ud.object(forKey: "notif_evening_enabled") as? Bool) ?? eveningEnabled

        if let t = ud.object(forKey: "notif_morning_time") as? TimeInterval {
            morningTime = Date(timeIntervalSince1970: t)
        }
        if let t = ud.object(forKey: "notif_midday_time") as? TimeInterval {
            middayTime = Date(timeIntervalSince1970: t)
        }
        if let t = ud.object(forKey: "notif_evening_time") as? TimeInterval {
            eveningTime = Date(timeIntervalSince1970: t)
        }

        // Voice guidance
        if ud.object(forKey: "voice_guidance") != nil {
            voiceGuidanceEnabled = ud.bool(forKey: "voice_guidance")
        }
        TTSManager.shared.enabled = voiceGuidanceEnabled

        // Finalize
        refreshToday()
    }

    // MARK: Helpers
    static func makeTime(_ hour: Int, _ minute: Int) -> Date {
        var c = DateComponents(); c.hour = hour; c.minute = minute
        return Calendar.current.date(from: c) ?? Date()
    }

    func refreshToday(date: Date = .now) {
        var picks: [Verse] = []
        let packs = prioritizedPacks()
        for p in packs { if let v = p.verses.first { picks.append(v) } }
        todayVerses = picks
    }

    func prioritizedPacks() -> [VersePack] {
        let map: [FocusArea: String] = [
            .health: "health-anxiety",
            .panic:  "panic-fear",
            .sleep:  "night-peace",
            .worry:  "daily-worry",
            .grief:  "daily-worry",
            .general:"health-anxiety"
        ]
        let wanted = focusAreas.compactMap { map[$0] }
        let selected = library.packs.filter { wanted.contains($0.id) }
        return selected.isEmpty ? Array(library.packs.prefix(4)) : selected
    }
}
