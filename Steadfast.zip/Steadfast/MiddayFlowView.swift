import SwiftUI

struct MiddayFlowView: View {
    // Total flow length
    var totalSeconds: Int = 90

    // Box breathing counts (4–4–4–4)
    var boxCount: Int = 4

    // Stage timings (slower prompts)
    private let welcomeHold: TimeInterval   = 3.0
    private let heHold: TimeInterval        = 3.0
    private let gratitudeHold: TimeInterval = 18.0
    private let thankHold: TimeInterval     = 6.0
    private let breatheHold: TimeInterval   = 3.0
    private let fade: TimeInterval          = 0.6

    @Environment(\.dismiss) private var dismiss

    // Stages
    enum Stage { case welcome, he, gratitude, thankGod, breathePrompt, circle, done }
    enum Phase { case inhale, hold1, exhale, hold2 }

    @State private var stage: Stage = .welcome
    @State private var remaining: Int = 90

    // UI flags
    @State private var showWelcome = false
    @State private var showHe = false
    @State private var showPrompt = false
    @State private var pulsePrompt = false
    @State private var showThank = false
    @State private var showBreathe = false
    @State private var showCircle = false

    // Circle state
    @State private var phase: Phase = .inhale
    @State private var phaseRemaining: Int = 0
    @State private var scale: CGFloat = 0.95

    // Timers
    @State private var globalTimer: Timer?
    @State private var phaseTimer: Timer?
    @State private var scheduled: [DispatchWorkItem] = []

    var body: some View {
        ZStack {
            // Calm clouds background
            CalmCloudsBackground(
                base: Theme.bg,
                cloudColors: [
                    Color.purple.opacity(0.54),
                    Color.mint.opacity(0.52),
                    Color.blue.opacity(0.60)
                ],
                count: 10,
                speed: 0.08
            )

            // CONTENT
            Group {
                switch stage {
                case .welcome:
                    VStack(spacing: 18) {
                        Spacer(minLength: 40)
                        if showWelcome {
                            Text("Welcome to your midday reset")
                                .font(.title3).bold()
                                .multilineTextAlignment(.center)
                                .transition(.opacity)
                        }
                        Spacer(minLength: 40)
                    }
                    .padding()

                case .he:
                    VStack(spacing: 18) {
                        Spacer(minLength: 40)
                        if showHe {
                            Text("He is with you.")
                                .font(.title3)
                                .multilineTextAlignment(.center)
                                .transition(.opacity)
                        }
                        Spacer(minLength: 40)
                    }
                    .padding()

                case .gratitude:
                    VStack(spacing: 18) {
                        Spacer(minLength: 40)
                        if showPrompt {
                            Text("Name one thing you’re grateful for in this moment.")
                                .font(.title3)
                                .multilineTextAlignment(.center)
                                .foregroundStyle(Theme.inkSecondary)
                                .padding(.horizontal)
                                .scaleEffect(pulsePrompt ? 1.04 : 0.96)
                                .animation(.easeInOut(duration: 1.8).repeatForever(autoreverses: true),
                                           value: pulsePrompt)
                                .transition(.opacity)
                        }
                        Spacer(minLength: 40)
                    }
                    .padding()

                case .thankGod:
                    VStack(spacing: 18) {
                        Spacer(minLength: 40)
                        if showThank {
                            Text("Use this time to thank God.")
                                .font(.title3)
                                .multilineTextAlignment(.center)
                                .transition(.opacity)
                        }
                        Spacer(minLength: 40)
                    }
                    .padding()

                case .breathePrompt:
                    VStack(spacing: 18) {
                        Spacer(minLength: 40)
                        if showBreathe {
                            Text("Let’s breathe.")
                                .font(.title3).bold()
                                .multilineTextAlignment(.center)
                                .transition(.opacity)
                        }
                        Spacer(minLength: 40)
                    }
                    .padding()

                case .circle:
                    VStack(spacing: 16) {
                        Spacer()
                        ZStack {
                            Circle()
                                .stroke(.thinMaterial, lineWidth: 8)
                                .frame(width: 220, height: 220)
                                .scaleEffect(scale)
                                .opacity(showCircle ? 1 : 0)
                            VStack(spacing: 6) {
                                Text(titleForPhase(phase)).font(.headline)
                                Text("\(phaseRemaining)s").font(.footnote).monospacedDigit()
                            }
                            .opacity(showCircle ? 1 : 0)
                        }

                        // Dynamic inhale/exhale scripture line
                        Text(scriptureLine(for: phase))
                            .multilineTextAlignment(.center)
                            .font(.title3)
                            .padding(.horizontal)
                            .transition(.opacity)
                            .id(phase)

                        Spacer()
                    }
                    .padding()

                case .done:
                    VStack(spacing: 14) {
                        Spacer()
                        Image(systemName: "checkmark.seal.fill").font(.largeTitle)
                        Text("Nice reset.").font(.title3).bold()
                        Text("Carry this steadiness into your next step.")
                            .foregroundStyle(Theme.inkSecondary)
                        Button("Close") { stopAll(); dismiss() }
                            .buttonStyle(.borderedProminent)
                        Spacer()
                    }.padding()
                }
            }

            // Bottom countdown
            VStack {
                Spacer()
                Text(timeString(remaining))
                    .font(.callout).monospacedDigit()
                    .foregroundStyle(Theme.inkSecondary)
                    .padding(.vertical, 8)
            }
            .padding(.bottom, 28)
        }
        .navigationTitle("Midday")
        .navigationBarTitleDisplayMode(.inline)
        /*.toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button("Close") { stopAll(); dismiss() }
            }
        }*/
        .onAppear { start() }
        .onDisappear { stopAll() }
    }

    // MARK: - Flow
    private func start() {
        stopAll()
        remaining = totalSeconds
        stage = .welcome

        // 🔊 Ambient pad on
        SoundManager.shared.playAmbient(named: "meditate1", startVolume: 0.0, loop: true)
        SoundManager.shared.fade(to: 0.6, duration: 0.8)

        // Welcome → He → Gratitude → Thank God → Breathe → Circle
        withAnimation(.easeInOut(duration: fade)) { showWelcome = true }
        schedule(after: welcomeHold) {
            withAnimation(.easeInOut(duration: fade)) { showWelcome = false }
            schedule(after: fade) {
                stage = .he
                withAnimation(.easeInOut(duration: fade)) { showHe = true }
                schedule(after: heHold) {
                    withAnimation(.easeInOut(duration: fade)) { showHe = false }
                    schedule(after: fade) {
                        stage = .gratitude
                        withAnimation(.easeInOut(duration: 0.6)) { showPrompt = true; pulsePrompt = true }
                        schedule(after: gratitudeHold) {
                            withAnimation(.easeInOut(duration: 0.6)) { showPrompt = false; pulsePrompt = false }
                            schedule(after: fade) {
                                stage = .thankGod
                                withAnimation(.easeInOut(duration: fade)) { showThank = true }
                                schedule(after: thankHold) {
                                    withAnimation(.easeInOut(duration: fade)) { showThank = false }
                                    schedule(after: fade) {
                                        stage = .breathePrompt
                                        withAnimation(.easeInOut(duration: fade)) { showBreathe = true }
                                        schedule(after: breatheHold) {
                                            withAnimation(.easeInOut(duration: fade)) { showBreathe = false }
                                            schedule(after: fade) {
                                                stage = .circle
                                                startCircle()
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Global countdown → fade circle, then done
        globalTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { t in
            remaining -= 1
            if remaining <= 0 {
                t.invalidate()
                stopPhaseTimer()
                withAnimation(.easeInOut(duration: 0.5)) { showCircle = false }
                // 🔇 Ambient off
                SoundManager.shared.fade(to: 0.0, duration: 0.6, stopAfter: true)
                schedule(after: 1.0) { stage = .done }
            }
        }
    }

    // MARK: - Circle
    private func startCircle() {
        showCircle = true
        phase = .inhale
        phaseRemaining = boxCount
        animateScale(to: 1.12, seconds: boxCount)
        haptic(for: .inhale)

        phaseTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            phaseRemaining -= 1
            if phaseRemaining <= 0 {
                switch phase {
                case .inhale:
                    phase = .hold1;  phaseRemaining = boxCount
                case .hold1:
                    phase = .exhale; phaseRemaining = boxCount
                    animateScale(to: 0.85, seconds: boxCount)
                    haptic(for: .exhale)
                case .exhale:
                    phase = .hold2;  phaseRemaining = boxCount
                case .hold2:
                    phase = .inhale; phaseRemaining = boxCount
                    animateScale(to: 1.12, seconds: boxCount)
                    haptic(for: .inhale)
                }
            }
        }
    }

    private func haptic(for phase: Phase) {
        switch phase {
        case .inhale: UIImpactFeedbackGenerator(style: .soft).impactOccurred()
        case .exhale: UIImpactFeedbackGenerator(style: .rigid).impactOccurred()
        default: break
        }
    }

    private func scriptureLine(for p: Phase) -> String {
        switch p {
        case .inhale, .hold1:
            return "“Trust in the Lord with all your heart.”"
        case .exhale, .hold2:
            return "“He will make straight your paths.”"
        }
    }

    private func animateScale(to target: CGFloat, seconds: Int) {
        withAnimation(.easeInOut(duration: Double(seconds))) { scale = target }
    }

    // Helpers
    private func schedule(after seconds: TimeInterval, _ block: @escaping () -> Void) {
        let w = DispatchWorkItem(block: block)
        scheduled.append(w)
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds, execute: w)
    }
    private func stopPhaseTimer() { phaseTimer?.invalidate(); phaseTimer = nil }
    private func stopAll() {
        globalTimer?.invalidate(); globalTimer = nil
        stopPhaseTimer()
        scheduled.forEach { $0.cancel() }
        scheduled.removeAll()
        SoundManager.shared.fade(to: 0.0, duration: 0.6, stopAfter: true)
    }

    private func titleForPhase(_ p: Phase) -> String {
        switch p {
        case .inhale: "Inhale"
        case .hold1:  "Hold"
        case .exhale: "Exhale"
        case .hold2:  "Hold"
        }
    }
    private func timeString(_ t: Int) -> String {
        let m = max(t,0)/60, s = max(t,0)%60
        return String(format: "%01d:%02d", m, s)
    }
}
