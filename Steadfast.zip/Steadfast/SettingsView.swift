import SwiftUI
import UserNotifications

struct SettingsView: View {
    @EnvironmentObject var vm: AppViewModel
    @State private var authStatus: UNAuthorizationStatus = .notDetermined
    @State private var showingDeniedAlert = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack {
                        Text("Notifications")
                        Spacer()
                        statusBadge
                    }

                    Toggle("Enable daily reminders", isOn: $vm.notifEnabled)
                        .onChange(of: vm.notifEnabled) { _ in apply() }

                    // Morning
                    HStack {
                        Toggle("Morning", isOn: $vm.morningEnabled)
                        Spacer()
                        DatePicker("", selection: $vm.morningTime, displayedComponents: .hourAndMinute)
                            .labelsHidden()
                            .disabled(!vm.notifEnabled || !vm.morningEnabled)
                    }
                    // Midday
                    HStack {
                        Toggle("Midday", isOn: $vm.middayEnabled)
                        Spacer()
                        DatePicker("", selection: $vm.middayTime, displayedComponents: .hourAndMinute)
                            .labelsHidden()
                            .disabled(!vm.notifEnabled || !vm.middayEnabled)
                    }
                    // Evening
                    HStack {
                        Toggle("Evening", isOn: $vm.eveningEnabled)
                        Spacer()
                        DatePicker("", selection: $vm.eveningTime, displayedComponents: .hourAndMinute)
                            .labelsHidden()
                            .disabled(!vm.notifEnabled || !vm.eveningEnabled)
                    }

                    Button {
                        requestAndApply()
                    } label: {
                        Label("Save & Schedule", systemImage: "bell.badge")
                    }
                    .buttonStyle(.borderedProminent)

                    Button {
                        NotificationManager.shared.cancelDailyCheckins()
                    } label: {
                        Label("Disable scheduled reminders", systemImage: "bell.slash")
                    }
                    .buttonStyle(.bordered)
                }
                
                // --- NEW: Voice guidance (TTS) ---
                                Section("Voice guidance") {
                                    Toggle("Enable text-to-speech guidance", isOn: $vm.voiceGuidanceEnabled)
                                        .onChange(of: vm.voiceGuidanceEnabled) { on in
                                            TTSManager.shared.enabled = on
                                        }

                                    Button {
                                        // quick sample line (only plays when enabled)
                                        TTSManager.shared.speak("This is Steadfast voice guidance. You can turn me off any time in Settings.",
                                                                rate: 0.46, pitch: 1.0)
                                    } label: {
                                        Label("Play sample", systemImage: "speaker.wave.2.fill")
                                    }
                                    .disabled(!vm.voiceGuidanceEnabled)
                                }

                Section {
                    Button {
                        NotificationManager.shared.openSystemSettings()
                    } label: {
                        Label("Open iOS Notification Settings", systemImage: "gearshape")
                    }
                } footer: {
                    Text("If notifications are Off or set to Deliver Quietly in iOS Settings, reminders may not appear.")
                        .font(.footnote)
                        .foregroundStyle(Theme.inkSecondary)
                }
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .tint(Theme.accent)
            .foregroundStyle(Theme.ink)
            .background(Theme.bg.ignoresSafeArea())
            .onAppear { refreshAuth() }
            .alert("Notifications are disabled", isPresented: $showingDeniedAlert) {
                Button("Open Settings") { NotificationManager.shared.openSystemSettings() }
                Button("OK", role: .cancel) { }
            } message: {
                Text("To receive reminders, allow notifications for Steadfast in iOS Settings.")
            }
        }
    }

    private var statusBadge: some View {
        Group {
            switch authStatus {
            case .authorized, .provisional, .ephemeral:
                Label("On", systemImage: "checkmark.circle.fill").foregroundStyle(.green)
            case .denied:
                Label("Off", systemImage: "xmark.circle.fill").foregroundStyle(.red)
            case .notDetermined:
                Label("Ask", systemImage: "questionmark.circle.fill").foregroundStyle(.orange)
            @unknown default:
                Label("Unknown", systemImage: "questionmark.circle").foregroundStyle(.orange)
            }
        }
        .font(.footnote.weight(.semibold))
    }

    private func refreshAuth() {
        NotificationManager.shared.fetchAuthorizationStatus { status in
            authStatus = status
        }
    }

    private func requestAndApply() {
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            DispatchQueue.main.async {
                if settings.authorizationStatus == .denied {
                    showingDeniedAlert = true
                } else if settings.authorizationStatus == .notDetermined {
                    NotificationManager.shared.requestAndScheduleDailyCheckins()
                    // Status will update next appear; also schedule from current settings
                    NotificationManager.shared.scheduleDailyFromSettings()
                } else {
                    apply()
                }
                refreshAuth()
            }
        }
    }

    private func apply() {
        // Re-schedule with the current toggles/times
        NotificationManager.shared.scheduleDailyFromSettings()
    }
}
