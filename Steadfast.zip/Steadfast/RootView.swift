import SwiftUI

struct RootView: View {
    @EnvironmentObject var vm: AppViewModel
    
    var body: some View {
        TabView {
            HomeView()
                .tabItem { Label("Home", systemImage: "house.fill") }
            LibraryView()
                .tabItem { Label("Library", systemImage: "book.fill") }
            PrayerPlansView()
                .tabItem { Label("Prayer", systemImage: "hands.sparkles.fill") }
            SettingsView()
                .tabItem { Label("Settings", systemImage: "gearshape.fill") }
        }
        .tint(Theme.accent)
        .background(Theme.bg.ignoresSafeArea())
        .sheet(isPresented: $vm.showSOS) { SOSFlow() }
    }
}
