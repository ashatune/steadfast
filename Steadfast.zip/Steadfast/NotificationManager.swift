// NotificationManager.swift
import Foundation
import UserNotifications
import UIKit

final class NotificationManager {
    static let shared = NotificationManager(); private init() {}

    private let ids = [
        "steadfast.morning.checkin",
        "steadfast.midday.checkin",
        "steadfast.evening.checkin"
    ]

    func requestAndScheduleDailyCheckins() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert,.sound,.badge]) { granted, _ in
            DispatchQueue.main.async {
                if granted { self.scheduleDailyFromSettings() }
            }
        }
    }

    /// Read settings from UserDefaults and (re)schedule
    func scheduleDailyFromSettings() {
        let ud = UserDefaults.standard
        let master = ud.object(forKey: "notif_enabled") as? Bool ?? true

        let mEnabled = ud.object(forKey: "notif_morning_enabled") as? Bool ?? true
        let mdEnabled = ud.object(forKey: "notif_midday_enabled") as? Bool ?? true
        let eEnabled = ud.object(forKey: "notif_evening_enabled") as? Bool ?? true

        let mTime = (ud.object(forKey: "notif_morning_time") as? TimeInterval).map(Date.init(timeIntervalSince1970:)) ?? Date()
        let mdTime = (ud.object(forKey: "notif_midday_time") as? TimeInterval).map(Date.init(timeIntervalSince1970:)) ?? Date()
        let eTime = (ud.object(forKey: "notif_evening_time") as? TimeInterval).map(Date.init(timeIntervalSince1970:)) ?? Date()

        scheduleDaily(masterEnabled: master,
                      morning: (mEnabled, mTime),
                      midday:  (mdEnabled, mdTime),
                      evening: (eEnabled, eTime))
    }

    func scheduleDaily(masterEnabled: Bool,
                       morning: (enabled: Bool, date: Date),
                       midday:  (enabled: Bool, date: Date),
                       evening: (enabled: Bool, date: Date)) {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: ids)

        guard masterEnabled else { return }

        func comps(_ date: Date) -> DateComponents {
            let cal = Calendar.current
            let h = cal.component(.hour, from: date)
            let m = cal.component(.minute, from: date)
            var dc = DateComponents(); dc.hour = h; dc.minute = m; dc.second = 0
            return dc
        }

        func add(_ id: String, _ title: String, _ body: String, _ date: Date) {
            let content = UNMutableNotificationContent()
            content.title = title; content.body = body; content.sound = .default
            let trigger = UNCalendarNotificationTrigger(dateMatching: comps(date), repeats: true)
            let req = UNNotificationRequest(identifier: id, content: content, trigger: trigger)
            center.add(req)
        }

        if morning.enabled {
            add(ids[0], "Morning check-in", "Take 60 seconds with today’s verse and a breath.", morning.date)
        }
        if midday.enabled {
            add(ids[1], "Midday reset", "Pause, breathe, and cast your cares.", midday.date)
        }
        if evening.enabled {
            add(ids[2], "Evening wind-down", "Lay it down and rest in God’s care.", evening.date)
        }
    }

    func cancelDailyCheckins() {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ids)
    }

    func openSystemSettings() {
        guard let url = URL(string: UIApplication.openSettingsURLString),
              UIApplication.shared.canOpenURL(url) else { return }
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }

    func fetchAuthorizationStatus(_ cb: @escaping (UNAuthorizationStatus)->Void) {
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            DispatchQueue.main.async { cb(settings.authorizationStatus) }
        }
    }
}
