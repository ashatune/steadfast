import SwiftUI

struct MorningFlowView: View {
    let verse: Verse

    // Total flow config (3 minutes)
    var totalSeconds: Int = 180
    var inhaleSecs: Int = 4
    var exhaleSecs: Int = 6

    // Stage timings
    private let greetingSeconds: TimeInterval      = 3.0    // “Good morning”
    private let prepSeconds: TimeInterval          = 4.0    // “Let’s ground…”
    private let comfortSeconds: TimeInterval       = 4.0    // “Get comfortable…”
    private let prayerPerLineSeconds: TimeInterval = 4.5    // each prayer line
    private let verseSeconds: TimeInterval         = 12.0   // show verse
    private let promptOverlaySeconds: TimeInterval = 12.0   // pulsing prompt over verse

    private enum Stage { case greeting, prep, comfort, prayer, verse, promptOverlay, circle, done }
    private enum BreathPhase { case inhale, exhale }

    @Environment(\.dismiss) private var dismiss

    // Flow state
    @State private var stage: Stage = .greeting
    @State private var remaining: Int = 180
    @State private var startTime: Date?

    // UI flags
    @State private var showGreeting = false
    @State private var showPrep = false
    @State private var showComfort = false
    @State private var showVerse = false
    @State private var showPrompt = false
    @State private var pulsePrompt = false

    // Prayer sequence
    @State private var prayerIndex = 0
    @State private var prayerVisible = false
    @State private var prayerTask: Task<Void, Never>?

    // Circle state
    @State private var showCircle = false
    @State private var phase: BreathPhase = .inhale
    @State private var phaseRemaining: Int = 0
    @State private var scale: CGFloat = 0.95

    // Timers
    @State private var globalTimer: Timer?
    @State private var phaseTimer: Timer?
    @State private var scheduled: [DispatchWorkItem] = []

    var body: some View {
        ZStack {
            // Calm clouds
            CalmCloudsBackground(
                base: Theme.bg,
                cloudColors: [
                    Color.blue.opacity(0.74),
                    Color.mint.opacity(0.52),
                    Color.purple.opacity(0.80)
                ],
                count: 10,
                speed: 0.08
            )

            // CONTENT
            Group {
                switch stage {
                case .greeting:
                    CenterStage {
                        if showGreeting {
                            Text("Good morning")
                                .font(.title).bold()
                                .transition(.opacity)
                        }
                    }

                case .prep:
                    CenterStage {
                        if showPrep {
                            Text("Let’s ground ourselves for the day,\nand spend a few minutes with your Creator.")
                                .font(.title3)
                                .multilineTextAlignment(.center)
                                .foregroundStyle(.secondary)
                                .padding(.horizontal)
                                .transition(.opacity)
                        }
                    }

                case .comfort:
                    CenterStage {
                        if showComfort {
                            Text("HE cares about you.")
                                .font(.title3)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)
                                .transition(.opacity)
                        }
                    }

                case .prayer:
                    CenterStage {
                        if let line = currentPrayerLine {
                            Text(line)
                                .font(.title3)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 20)
                                .opacity(prayerVisible ? 1 : 0)
                                .animation(.easeInOut(duration: 0.6), value: prayerVisible)
                                .transition(.opacity)
                        }
                    }

                case .verse:
                    CenterStage {
                        if showVerse {
                            VStack(spacing: 10) {
                                Text(verse.ref).font(.headline)
                                Text(verseTextOrFetch())
                                    .font(.title3)
                                    .multilineTextAlignment(.center)
                                    .padding(.horizontal)
                            }
                            .transition(.opacity)
                        }
                    }

                case .promptOverlay:
                    CenterStage {
                        VStack(spacing: 18) {
                            Text("What does this verse mean to you as you prepare for today?")
                                .font(.subheadline)
                                .multilineTextAlignment(.center)
                                .foregroundStyle(.secondary)
                                .padding(.horizontal)
                                .scaleEffect(pulsePrompt ? 1.04 : 0.96)
                                .animation(.easeInOut(duration: 1.8).repeatForever(autoreverses: true), value: pulsePrompt)
                                .opacity(showPrompt ? 1 : 0)
                                .animation(.easeInOut(duration: 0.6), value: showPrompt)

                            VStack(spacing: 8) {
                                Text(verse.ref).font(.headline)
                                Text(verseTextOrFetch())
                                    .font(.title3)
                                    .multilineTextAlignment(.center)
                                    .padding(.horizontal)
                            }
                            .opacity(showVerse ? 1 : 0)
                            .animation(.easeInOut(duration: 0.6), value: showVerse)
                        }
                    }

                case .circle:
                    CenterStage {
                        VStack(spacing: 16) {
                            ZStack {
                                Circle()
                                    .stroke(.thinMaterial, lineWidth: 8)
                                    .frame(width: 220, height: 220)
                                    .scaleEffect(scale)
                                    .opacity(showCircle ? 1 : 0)
                                VStack(spacing: 6) {
                                    Text(phase == .inhale ? "Inhale" : "Exhale").font(.headline)
                                    Text("\(phaseRemaining)s")
                                        .font(.footnote)
                                        .monospacedDigit()
                                }
                                .opacity(showCircle ? 1 : 0)
                            }
                            Text("“This is the day the Lord has made; I will rejoice and be glad in it.”")
                                .multilineTextAlignment(.center)
                                .font(.callout)
                                .foregroundStyle(.secondary)
                                .padding(.horizontal)
                        }
                    }

                case .done:
                    CenterStage {
                        VStack(spacing: 14) {
                            Image(systemName: "checkmark.seal.fill")
                                .font(.largeTitle)
                                .foregroundStyle(Theme.accent)
                            Text("Well done.")
                                .font(.title3).bold()
                            Text("Take this steady heart into your day.")
                                .foregroundStyle(.secondary)
                            Button("Close") { dismissAndStop() }
                                .buttonStyle(.borderedProminent)
                                .padding(.top, 6)
                        }
                    }
                }
            }
            .padding()

            // Bottom countdown
            VStack {
                Spacer()
                Text(timeString(remaining))
                    .font(.callout)
                    .monospacedDigit()
                    .foregroundStyle(Theme.inkSecondary)
                    .padding(.vertical, 8)
            }
            .padding(.bottom, 28)
        }
        .navigationTitle("Morning")
        .navigationBarTitleDisplayMode(.inline)
        //.toolbar { ToolbarItem(placement: .topBarLeading) { Button("Close") { dismissAndStop() } } }
        .onAppear { start() }
        .onDisappear { stopAll() }
    }

    // MARK: - Flow
    private func start() {
        stopAll()
        remaining = totalSeconds
        startTime = Date()
        stage = .greeting

        // Ambient pad
        SoundManager.shared.playAmbient(named: "meditate1", startVolume: 0.0, loop: true)
        SoundManager.shared.fade(to: 0.6, duration: 1.0)

        withAnimation(.easeInOut(duration: 0.6)) { showGreeting = true }
        schedule(after: greetingSeconds) {
            withAnimation(.easeInOut(duration: 0.6)) { showGreeting = false }
            stage = .prep
            withAnimation(.easeInOut(duration: 0.6)) { showPrep = true }
            schedule(after: prepSeconds) {
                withAnimation(.easeInOut(duration: 0.6)) { showPrep = false }
                stage = .comfort
                withAnimation(.easeInOut(duration: 0.6)) { showComfort = true }
                schedule(after: comfortSeconds) {
                    withAnimation(.easeInOut(duration: 0.6)) { showComfort = false }
                    // Prayer sequence (multi-prompt)
                    stage = .prayer
                    startPrayerSequence()
                }
            }
        }

        // Global countdown
        globalTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { t in
            remaining -= 1
            if remaining <= 0 {
                t.invalidate()
                stopBreathTimer()
                SoundManager.shared.fade(to: 0.0, duration: 0.6, stopAfter: true)
                stage = .done
            }
        }
    }

    private func startPrayerSequence() {
        prayerTask?.cancel()
        prayerIndex = 0
        prayerVisible = false

        prayerTask = Task {
            for i in prayerLines.indices {
                await MainActor.run {
                    prayerIndex = i
                    withAnimation(.easeInOut(duration: 0.6)) { prayerVisible = true }
                }
                try? await Task.sleep(nanoseconds: UInt64(prayerPerLineSeconds * 1_000_000_000))
                await MainActor.run {
                    withAnimation(.easeInOut(duration: 0.6)) { prayerVisible = false }
                }
                try? await Task.sleep(nanoseconds: 600_000_000) // settle fade
                if Task.isCancelled { return }
            }

            // After prayer → verse
            await MainActor.run {
                stage = .verse
                withAnimation(.easeInOut(duration: 0.6)) { showVerse = true }
            }
            try? await Task.sleep(nanoseconds: UInt64(verseSeconds * 1_000_000_000))

            // → pulsing prompt overlay (keep verse visible)
            await MainActor.run {
                stage = .promptOverlay
                showPrompt = true
                pulsePrompt = true
                // keep verse visible underneath
            }
            try? await Task.sleep(nanoseconds: UInt64(promptOverlaySeconds * 1_000_000_000))

            // fade out prompt + verse, then circle for remaining time
            await MainActor.run {
                withAnimation(.easeInOut(duration: 0.6)) {
                    showPrompt = false
                    pulsePrompt = false
                    showVerse = false
                }
            }
            try? await Task.sleep(nanoseconds: 600_000_000) // settle
            await MainActor.run {
                startCircleForRemaining()
            }
        }
    }

    private var currentPrayerLine: String? {
        guard prayerLines.indices.contains(prayerIndex) else { return nil }
        return prayerLines[prayerIndex]
    }

    private func startCircleForRemaining() {
        let elapsed = Int(Date().timeIntervalSince(startTime ?? Date()))
        let remainingForCircle = max(20, totalSeconds - elapsed)
        startCircle(seconds: remainingForCircle)
    }

    private func startCircle(seconds: Int) {
        stage = .circle
        showCircle = true
        phase = .inhale
        phaseRemaining = inhaleSecs
        animateScale(to: 1.12, seconds: inhaleSecs)
        hapticSoft()

        phaseTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            phaseRemaining -= 1
            if phaseRemaining <= 0 {
                switch phase {
                case .inhale:
                    phase = .exhale
                    phaseRemaining = exhaleSecs
                    animateScale(to: 0.85, seconds: exhaleSecs)
                    hapticSoft()
                case .exhale:
                    phase = .inhale
                    phaseRemaining = inhaleSecs
                    animateScale(to: 1.12, seconds: inhaleSecs)
                    hapticSoft()
                }
            }
        }
    }

    // MARK: - Scheduling / teardown
    private func schedule(after seconds: TimeInterval, _ block: @escaping () -> Void) {
        let w = DispatchWorkItem(block: block)
        scheduled.append(w)
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds, execute: w)
    }

    private func stopBreathTimer() { phaseTimer?.invalidate(); phaseTimer = nil }

    private func stopAll() {
        globalTimer?.invalidate(); globalTimer = nil
        stopBreathTimer()
        scheduled.forEach { $0.cancel() }
        scheduled.removeAll()
        prayerTask?.cancel(); prayerTask = nil
        SoundManager.shared.fade(to: 0.0, duration: 0.6, stopAfter: true)
    }

    private func dismissAndStop() { stopAll(); dismiss() }

    // MARK: - Helpers
    private func verseTextOrFetch() -> String {
        if let t = verse.text, !t.isEmpty { return t }
        if let parsed = BibleStore.shared.parseReference(verse.ref) {
            let vs = BibleStore.shared.passage(book: parsed.book,
                                               chapter: parsed.chapter,
                                               verseStart: parsed.verseStart,
                                               verseEnd: parsed.verseEnd)
            return vs.map { $0.text }.joined(separator: " ")
        }
        return verse.ref
    }

    private func timeString(_ t: Int) -> String {
        let m = max(t,0)/60, s = max(t,0)%60
        return String(format: "%01d:%02d", m, s)
    }

    private func animateScale(to target: CGFloat, seconds: Int) {
        withAnimation(.easeInOut(duration: Double(seconds))) { scale = target }
    }

    private func hapticSoft() {
        UIImpactFeedbackGenerator(style: .soft).impactOccurred()
    }

    private var prayerLines: [String] {
        [
            "Heavenly Father, thank You for the gift of this new day.",
            "Fill my heart with Your peace and my mind with Your wisdom.",
            "Guide my steps, my words, and my thoughts so that they honor You.",
            "Give me strength for what lies ahead and remind me that I am never alone.",
            "May Your light shine through me today.",
            "Amen."
        ]
    }
}

// Centers any content in the available space.
private struct CenterStage<Content: View>: View {
    @ViewBuilder var content: () -> Content
    var body: some View {
        GeometryReader { geo in
            VStack { content() }
                .frame(width: geo.size.width, height: geo.size.height, alignment: .center)
        }
    }
}
